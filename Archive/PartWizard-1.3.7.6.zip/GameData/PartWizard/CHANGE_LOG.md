# Part Wizard :: Change Log

* 2018-1109: 1.3.7.6 (Lisias) for KSP 1.4.1+; 1.5
	+ Using KSPe Facilities
		- Logging
		- Config Data
		- Assets  
* 2018-1031: 1.3.7.5 (linuxgurugamer) for KSP 1.5.1
	+ Version bump for 1.5 rebuild
* 2018-0511: 1.3.7.4 (linuxgurugamer) for KSP 1.4.3
	+ Added dependency checks for clickthroughblocker and toolbarcontroller
* 2018-0510: 1.3.7.3 (linuxgurugamer) for KSP 1.4.3
	+ Version bump to fix CKAN and compile issues
* 2018-0509: 1.3.7.2 (linuxgurugamer) for KSP 1.4.3
	+ Version bump to fix CKAN
* 2018-0507: 1.3.7.1 (linuxgurugamer) for KSP 1.4.3
	+ Updated code for Toolbarcontroller
	+ Added ToolbarRegistration
	+ removed blizzy/stock options from setting
* 2018-0403: 1.3.7 (linuxgurugamer) for KSP 1.4.2
	+ Updated for 1.4.1
	+ Added support for ToolbarController
	+ Added support for ClickThroughBlocker
* 2017-1008: 1.3.6 (linuxgurugamer) for KSP 1.3.1
	+ Updated for KSP 1.3.1
* 2017-0528: 1.3.4 (linuxgurugamer) for KSP 1.3.0
	+ Updated for 1.3
* 2017-0507: 1.3.3 (linuxgurugamer) for KSP 1.2.2
	+ Fixed issue where too many partcategories could cause an index error
* 2017-0214: 1.3.2 (linuxgurugamer) for KSP 1.2.2
	+ Fixed problem where individual categories couldn't be selected or deselected
* 2017-0106: 1.3.1 (linuxgurugamer) for KSP 1.2.2
	+ Fixed issue where parts with category = "none" was causing a nullref
* 2017-0104: 1.3.0 (linuxgurugamer) for KSP 1.2.2
	+ Updated for 1.2.2
	+ Added special colors for fuel lines and struts
	+ Added code to not constantly update the highlighting
	+ Added code to update AssemblyVersion from the .version file
* 2017-0103: 1.2.2a (linuxgurugamer) for KSP 1.2.2 PRE-RELEASE
	+ Added missing folder
* 2016-1230: 1 (linuxgurugamer) for KSP 1.2.2 PRE-RELEASE
	+ Updated for 1.2.2
	+ Added special colors for fuel lines and struts
	+ Added code to not constantly update the highlighting
* 2016-0623: 1.2.5.0 (ozraven) for KSP 1.1.3.
	+ Updated for KSP 1.1.3.
	+ Fixed loading toolbar preference when entering VAB/SPH.
* 2016-0420: 1.2.4.0 (ozraven) for KSP 1.1.
	+ Updated for KSP 1.1.
